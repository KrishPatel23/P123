import cv2
import csv
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from PIL import Image
import PIL.ImageOps
import os, ssl, time

# Load the datasets
x = np.load("image.npz")['arr_0']
y = pd.read_csv('labels.csv')["labels"]
# print(pd.Series(y).value_counts())
classes = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
nclasses = len(classes)

# Training and testing
xTrain, xTest, yTrain, yTest = train_test_split(x,y, random_state = 9, train_size = 7500, test_size = 2500)
xTrainScale = xTrain/255
xTestScale = xTest/255
classifer = LogisticRegression(solver = 'saga', multi_class = 'multinomial').fit(xTrainScale, yTrain)

# Prediction
prediction = classifer.predict(xTestScale)
accuracy = accuracy_score(yTest, prediction)
# print(accuracy)


capture = cv2.VideoCapture(0)
while(True):
    try:
        ret, frame = capture.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Drawing a box in center
        height, width = gray.shape
        upperLeft = (int(width/2 - 56), int(height/2 - 56))
        bottomRight = (int(width/2 + 56), int(height/2 + 56))

        cv2.rectangle(gray, upperLeft, bottomRight,(255,0,0), 2)

        # Region of interest - ROI
        roi = gray[upperLeft[1] : bottomRight[1], upperLeft[0] : bottomRight[0]]

        # Converting CV2 To Pillow
        Pillow = Image.fromarray(roi)
        pw1 = Pillow.convert("L")
        Resize = pw1.resize((28,28), Image.ANTIALIAS)
        Invert = PIL.ImageOps.invert(Resize)
        pixelFilter = 20

        minPix = np.percentile(Invert, pixelFilter)
        imageScale = np.clip(Invert-minPix, 0, 255)
        maxPix = np.max(Invert)
        Scale = np.asarray(Scale)/maxPix
        testSample = np.array(Scale).reshape(1,784)

        prediction = classifer.predict(testSample)
        print("The Predicted Alphabet is : ", prediction)
        cv2.imshow("frame", gray)
        
        if cv2.waitKey(1) & 0xff == ord("q"):
            break
    
    except Exception as e:
        pass

capture.release()
cv2.destroyAllWindows()